# install-windows-ps51.ps1
# Installs the native Windows PowerShell 5.1 Copilot HUD files into %USERPROFILE%\.copilot.
# Run from the extracted copilot-hud-windows-ps51 folder:
#   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install-windows-ps51.ps1

$ErrorActionPreference = "Stop"

function Get-CopilotHome {
    if (![string]::IsNullOrWhiteSpace($env:COPILOT_HOME)) {
        return $env:COPILOT_HOME
    }
    return (Join-Path $HOME ".copilot")
}

$sourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$copilotHome = Get-CopilotHome
$scriptsDest = Join-Path $copilotHome "scripts"

New-Item -ItemType Directory -Path $copilotHome -Force | Out-Null
New-Item -ItemType Directory -Path $scriptsDest -Force | Out-Null

Copy-Item -LiteralPath (Join-Path $sourceRoot "copilot-hud.ps1") -Destination (Join-Path $copilotHome "copilot-hud.ps1") -Force
Copy-Item -LiteralPath (Join-Path $sourceRoot "scripts\*.ps1") -Destination $scriptsDest -Force

$configFile = Join-Path $copilotHome "config.json"
$config = [pscustomobject]@{}

if (Test-Path $configFile) {
    Copy-Item -LiteralPath $configFile -Destination "$configFile.bak" -Force
    try {
        $raw = Get-Content -LiteralPath $configFile -Raw
        if (![string]::IsNullOrWhiteSpace($raw)) {
            $config = $raw | ConvertFrom-Json
        }
    } catch {
        $config = [pscustomobject]@{}
    }
}

if ($null -eq $config.PSObject.Properties["experimental"]) {
    Add-Member -InputObject $config -NotePropertyName "experimental" -NotePropertyValue $true -Force
} else {
    $config.experimental = $true
}

$hudPath = Join-Path $copilotHome "copilot-hud.ps1"
$statusCommand = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + $hudPath + '"'

$statusLine = [pscustomobject]@{
    type = "command"
    command = $statusCommand
}

if ($null -eq $config.PSObject.Properties["statusLine"]) {
    Add-Member -InputObject $config -NotePropertyName "statusLine" -NotePropertyValue $statusLine -Force
} else {
    $config.statusLine = $statusLine
}

($config | ConvertTo-Json -Depth 20) | Set-Content -LiteralPath $configFile -Encoding UTF8

Write-Host "Installed native PowerShell HUD:"
Write-Host "  $hudPath"
Write-Host ""
Write-Host "Updated Copilot config:"
Write-Host "  $configFile"
Write-Host ""
Write-Host "Manual hooks note:"
Write-Host "  Replace the plugin's hooks.json with hooks.windows.json only if your Copilot CLI hook runner supports the 'command' field."
Write-Host "  The original upstream hooks.json uses Bash, so the status line works without hooks, but tool/agent tracking needs the Windows hook file."
