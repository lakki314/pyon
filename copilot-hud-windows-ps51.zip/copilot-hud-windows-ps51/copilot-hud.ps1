# copilot-hud.ps1
# Native Windows PowerShell 5.1 HUD renderer for GitHub Copilot CLI.
# No Node.js. No jq. Designed for Windows Terminal / modern console.
# Optional env vars:
#   COPILOT_HUD_NO_COLOR=1   disables ANSI colors
#   COPILOT_HUD_ASCII=1      uses # and - instead of block characters
#   COPILOT_HUD_PATH_LEVELS=1 path display levels: 0,1,2,3

$ErrorActionPreference = "SilentlyContinue"

function Get-CopilotHome {
    if (![string]::IsNullOrWhiteSpace($env:COPILOT_HOME)) {
        return $env:COPILOT_HOME
    }
    return (Join-Path $HOME ".copilot")
}

function Get-JsonValue {
    param(
        [Parameter(Mandatory=$false)] $Obj,
        [Parameter(Mandatory=$true)] [string] $Path,
        [Parameter(Mandatory=$false)] $Default = $null
    )

    $cur = $Obj
    foreach ($part in $Path.Split(".")) {
        if ($null -eq $cur) { return $Default }
        $prop = $cur.PSObject.Properties[$part]
        if ($null -eq $prop) { return $Default }
        $cur = $prop.Value
    }

    if ($null -eq $cur) { return $Default }
    return $cur
}

$Esc = [char]27
$Reset = "$Esc[0m"

function Colorize {
    param([string]$Text, [string]$Color)

    if ($env:COPILOT_HUD_NO_COLOR -eq "1") {
        return $Text
    }

    $code = ""
    switch ($Color) {
        "dim"           { $code = "$Esc[2m" }
        "bold"          { $code = "$Esc[1m" }
        "red"           { $code = "$Esc[31m" }
        "green"         { $code = "$Esc[32m" }
        "yellow"        { $code = "$Esc[33m" }
        "blue"          { $code = "$Esc[34m" }
        "magenta"       { $code = "$Esc[35m" }
        "cyan"          { $code = "$Esc[36m" }
        "brightRed"     { $code = "$Esc[91m" }
        "brightGreen"   { $code = "$Esc[92m" }
        "brightYellow"  { $code = "$Esc[93m" }
        "brightBlue"    { $code = "$Esc[94m" }
        "brightMagenta" { $code = "$Esc[95m" }
        "brightCyan"    { $code = "$Esc[96m" }
        default         { $code = "" }
    }

    if ([string]::IsNullOrEmpty($code)) {
        return $Text
    }

    return "$code$Text$Reset"
}

function Dim { param([string]$Text) return (Colorize $Text "dim") }

function Get-ContextColor {
    param([double]$Percent)
    if ($Percent -ge 85) { return "red" }
    if ($Percent -ge 70) { return "yellow" }
    return "green"
}

function Render-Bar {
    param([double]$Percent, [int]$Width)

    if ($Percent -lt 0) { $Percent = 0 }
    if ($Percent -gt 100) { $Percent = 100 }

    $filled = [int][Math]::Round(($Percent / 100.0) * $Width)
    $empty = $Width - $filled

    if ($env:COPILOT_HUD_ASCII -eq "1") {
        $filledChar = "#"
        $emptyChar = "-"
    } else {
        $filledChar = [char]0x2588
        $emptyChar = [char]0x2591
    }

    $color = Get-ContextColor $Percent
    return "$(Colorize (($filledChar.ToString()) * $filled) $color)$(Dim (($emptyChar.ToString()) * $empty))"
}

function Format-Tokens {
    param([double]$N)
    if ($N -ge 1000000) { return ("{0:N1}M" -f ($N / 1000000.0)) }
    if ($N -ge 1000) { return ("{0:N1}k" -f ($N / 1000.0)) }
    return ("{0:N0}" -f $N)
}

function Format-Duration {
    param([double]$Ms)
    $mins = [int][Math]::Floor($Ms / 60000.0)
    if ($mins -lt 1) { return "<1m" }
    if ($mins -lt 60) { return "$($mins)m" }
    $hours = [int][Math]::Floor($mins / 60)
    $rem = $mins % 60
    return "$($hours)h $($rem)m"
}

function Format-ProjectPath {
    param([string]$Cwd)

    $levels = 1
    if (![string]::IsNullOrWhiteSpace($env:COPILOT_HUD_PATH_LEVELS)) {
        [int]::TryParse($env:COPILOT_HUD_PATH_LEVELS, [ref]$levels) | Out-Null
    }

    if ($levels -le 0) { return $Cwd }
    if ($levels -gt 3) { $levels = 3 }

    $parts = @($Cwd -split "[\\/]" | Where-Object { $_ -ne "" })
    if ($parts.Count -eq 0) { return $Cwd }

    $start = [Math]::Max(0, $parts.Count - $levels)
    return (($parts[$start..($parts.Count - 1)]) -join "/")
}

function Get-GitStatus {
    param([string]$Cwd)

    $branch = (& git -C $Cwd rev-parse --abbrev-ref HEAD 2>$null)
    if ($LASTEXITCODE -ne 0) { return $null }
    $branch = "$branch".Trim()
    if ([string]::IsNullOrWhiteSpace($branch) -or $branch -eq "HEAD") { return $null }

    $status = (& git -C $Cwd status --porcelain 2>$null)
    $dirty = ![string]::IsNullOrWhiteSpace(($status -join "`n"))

    $ahead = 0
    $behind = 0
    $counts = (& git -C $Cwd rev-list --count --left-right '@{upstream}...HEAD' 2>$null)
    if ($LASTEXITCODE -eq 0 -and ![string]::IsNullOrWhiteSpace($counts)) {
        $parts = "$counts".Trim() -split "\s+"
        if ($parts.Count -ge 2) {
            [int]::TryParse($parts[0], [ref]$behind) | Out-Null
            [int]::TryParse($parts[1], [ref]$ahead) | Out-Null
        }
    }

    return [pscustomobject]@{
        branch = $branch
        dirty = $dirty
        ahead = $ahead
        behind = $behind
    }
}

function Parse-ModelBadge {
    param([string]$DisplayName)

    if ([string]::IsNullOrWhiteSpace($DisplayName)) {
        return "Copilot"
    }

    $name = $DisplayName
    $mult = $null
    $effort = $null

    if ($name -match "\((\d+x)\)") {
        $mult = $Matches[1]
        $name = ($name -replace "\s*\(\d+x\)\s*", " ").Trim()
    }

    if ($name -match "\((low|medium|high|default)\)") {
        $effort = $Matches[1]
        $name = ($name -replace "\s*\((low|medium|high|default)\)\s*", " ").Trim()
    }

    $name = ($name -replace "^claude-", "" -replace "-", " ").Trim()
    if ([string]::IsNullOrWhiteSpace($name)) { $name = "Copilot" }

    $badge = $name
    if (![string]::IsNullOrWhiteSpace($mult)) { $badge += " $mult" }
    if (![string]::IsNullOrWhiteSpace($effort)) { $badge += "·$effort" }

    return $badge
}

function Get-StatusIcon {
    param([string]$Status)
    switch ($Status) {
        "success" { return "✓" }
        "failure" { return "✗" }
        "running" { return "◐" }
        "denied"  { return "⊘" }
        default   { return "·" }
    }
}

function Get-ToolIcon {
    param([string]$Name)
    switch ($Name.ToLower()) {
        "bash"   { return "⌨" }
        "powershell" { return "⌨" }
        "edit"   { return "✎" }
        "view"   { return "◉" }
        "create" { return "✚" }
        "glob"   { return "⊛" }
        "rg"     { return "⊛" }
        "grep"   { return "⊛" }
        "task"   { return "⟳" }
        default  { return "◈" }
    }
}

function Read-HudState {
    param([string]$StateFile)
    if (!(Test-Path $StateFile)) {
        return [pscustomobject]@{ recentTools = @(); agents = @(); sessionActive = $false }
    }

    try {
        $raw = Get-Content -LiteralPath $StateFile -Raw -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { throw "empty" }
        $state = $raw | ConvertFrom-Json
        if ($null -eq $state.PSObject.Properties["recentTools"]) {
            Add-Member -InputObject $state -NotePropertyName "recentTools" -NotePropertyValue @() -Force
        }
        if ($null -eq $state.PSObject.Properties["agents"]) {
            Add-Member -InputObject $state -NotePropertyName "agents" -NotePropertyValue @() -Force
        }
        return $state
    } catch {
        return [pscustomobject]@{ recentTools = @(); agents = @(); sessionActive = $false }
    }
}

$rawInput = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($rawInput)) {
    exit 0
}

try {
    $session = $rawInput | ConvertFrom-Json
} catch {
    exit 0
}

$copilotHome = Get-CopilotHome
$stateFile = Join-Path $copilotHome "hud-state.json"
$state = Read-HudState $stateFile

$cwd = Get-JsonValue $session "cwd" $null
if ([string]::IsNullOrWhiteSpace($cwd)) {
    $cwd = Get-JsonValue $state "cwd" (Get-Location).Path
}

$lines = New-Object System.Collections.Generic.List[string]

# Line 1: model, path, git, session, duration, changed lines
$line1Parts = New-Object System.Collections.Generic.List[string]

$modelName = Get-JsonValue $session "model.display_name" (Get-JsonValue $session "model.id" "Copilot")
$modelBadge = Parse-ModelBadge $modelName
$line1Parts.Add((Colorize "[$modelBadge]" "cyan"))

$remoteConnected = Get-JsonValue $session "remote.connected" $false
if ($remoteConnected -eq $true) {
    $line1Parts.Add((Colorize "◉ remote" "brightMagenta"))
}

$line1Parts.Add((Colorize (Format-ProjectPath $cwd) "yellow"))

$git = Get-GitStatus $cwd
if ($null -ne $git) {
    $branchText = $git.branch
    if ($git.dirty) { $branchText += "*" }
    if ($git.ahead -gt 0) { $branchText += " ↑$($git.ahead)" }
    if ($git.behind -gt 0) { $branchText += " ↓$($git.behind)" }
    $line1Parts.Add("$(Colorize "git:(" "magenta")$(Colorize $branchText "cyan")$(Colorize ")" "magenta")")
}

$sessionName = Get-JsonValue $session "session_name" $null
if (![string]::IsNullOrWhiteSpace($sessionName)) {
    $line1Parts.Add((Dim $sessionName))
}

$totalDuration = Get-JsonValue $session "cost.total_duration_ms" $null
if ($null -ne $totalDuration) {
    $line1Parts.Add((Dim ("⏱ " + (Format-Duration ([double]$totalDuration)))))
}

$added = [double](Get-JsonValue $session "cost.total_lines_added" 0)
$removed = [double](Get-JsonValue $session "cost.total_lines_removed" 0)
if ($added -gt 0 -or $removed -gt 0) {
    $line1Parts.Add("$(Colorize ("+{0:N0}" -f $added) "green")$(Dim "/")$(Colorize ("-{0:N0}" -f $removed) "red")")
}

$lines.Add(($line1Parts -join (Dim " │ ")))

# Line 2: context usage, requests, token breakdown, speed
$line2Parts = New-Object System.Collections.Generic.List[string]
$totalSize = Get-JsonValue $session "context_window.displayed_context_limit" (Get-JsonValue $session "context_window.context_window_size" $null)

if ($null -ne $totalSize -and [double]$totalSize -gt 0) {
    $pct = [double](Get-JsonValue $session "context_window.current_context_used_percentage" (Get-JsonValue $session "context_window.used_percentage" 0))
    $usedTokens = Get-JsonValue $session "context_window.current_context_tokens" $null
    if ($null -eq $usedTokens) {
        $remaining = Get-JsonValue $session "context_window.remaining_tokens" $null
        if ($null -ne $remaining) {
            $usedTokens = [double]$totalSize - [double]$remaining
        } else {
            $usedTokens = [Math]::Round(($pct * [double]$totalSize) / 100.0)
        }
    }

    $bar = Render-Bar $pct 10
    $contextColor = Get-ContextColor $pct
    $line2Parts.Add("$(Dim "Ctx") $bar $(Colorize ((Format-Tokens ([double]$usedTokens)) + "/" + (Format-Tokens ([double]$totalSize))) $contextColor) $(Colorize ("{0:N0}%" -f $pct) $contextColor)")
} else {
    $line2Parts.Add("$(Dim "Ctx") $(Render-Bar 0 10) $(Colorize "0%" "green")")
}

$reqs = Get-JsonValue $session "cost.total_premium_requests" $null
if ($null -ne $reqs) {
    $line2Parts.Add("$(Dim "Reqs") $(Colorize "$reqs" "brightBlue")")
}

$totalIn = [double](Get-JsonValue $session "context_window.total_input_tokens" 0)
$totalOut = [double](Get-JsonValue $session "context_window.total_output_tokens" 0)
$cacheRead = [double](Get-JsonValue $session "context_window.total_cache_read_tokens" (Get-JsonValue $session "context_window.current_usage.cache_read_input_tokens" 0))
$cacheWrite = [double](Get-JsonValue $session "context_window.total_cache_write_tokens" (Get-JsonValue $session "context_window.current_usage.cache_creation_input_tokens" 0))
if ($totalIn -gt 0 -or $totalOut -gt 0) {
    $cacheTotal = $cacheRead + $cacheWrite
    $tokInfo = "in:$(Format-Tokens $totalIn) out:$(Format-Tokens $totalOut)"
    if ($cacheTotal -gt 0) {
        $tokInfo += " cache:$(Format-Tokens $cacheTotal)"
    }
    $line2Parts.Add((Dim $tokInfo))
}

$apiMs = [double](Get-JsonValue $session "cost.total_api_duration_ms" 0)
if ($totalOut -gt 0 -and $apiMs -gt 0) {
    $tokPerSec = ($totalOut / $apiMs) * 1000.0
    $line2Parts.Add((Dim ("{0:N0} tok/s" -f $tokPerSec)))
}

$lines.Add(($line2Parts -join (Dim " │ ")))

# Line 3: recent tool activity from hook state
$stateSessionId = Get-JsonValue $state "sessionId" $null
$sessionId = Get-JsonValue $session "session_id" (Get-JsonValue $session "sessionId" $null)
$recentTools = @($state.recentTools)

if ($recentTools.Count -gt 0 -and ![string]::IsNullOrWhiteSpace($stateSessionId) -and ![string]::IsNullOrWhiteSpace($sessionId) -and $stateSessionId -eq $sessionId) {
    $summary = @{}
    $order = New-Object System.Collections.Generic.List[string]

    foreach ($tool in $recentTools) {
        $name = [string](Get-JsonValue $tool "name" "")
        if ([string]::IsNullOrWhiteSpace($name)) { continue }

        if (!$summary.ContainsKey($name)) {
            $summary[$name] = [pscustomobject]@{
                count = 1
                lastStatus = [string](Get-JsonValue $tool "status" "success")
                lastTarget = Get-JsonValue $tool "target" $null
            }
            $order.Add($name)
        } else {
            $summary[$name].count += 1
        }
    }

    $segments = New-Object System.Collections.Generic.List[string]
    foreach ($name in $order) {
        $info = $summary[$name]
        $icon = Get-ToolIcon $name
        $sIcon = Get-StatusIcon $info.lastStatus
        $color = "green"
        if ($info.lastStatus -eq "failure") { $color = "red" }
        elseif ($info.lastStatus -eq "running") { $color = "yellow" }

        $label = $name.Substring(0,1).ToUpper() + $name.Substring(1)
        if ($info.lastStatus -eq "running") {
            $part = Colorize "◐ $icon $label" $color
        } else {
            $part = Colorize "$sIcon $icon $label" $color
        }

        if (![string]::IsNullOrWhiteSpace([string]$info.lastTarget)) {
            $target = [string]$info.lastTarget
            if ($target.Length -gt 30) { $target = $target.Substring(0,30) }
            $part += (Dim ": $target")
        }
        if ($info.count -gt 1) {
            $part += (Dim " ×$($info.count)")
        }
        $segments.Add($part)
    }

    if ($segments.Count -gt 0) {
        $lines.Add(($segments -join (Dim " | ")))
    }
}

# Agent activity
$agents = @($state.agents)
if ($agents.Count -gt 0 -and ![string]::IsNullOrWhiteSpace($stateSessionId) -and ![string]::IsNullOrWhiteSpace($sessionId) -and $stateSessionId -eq $sessionId) {
    $maxAgents = 5
    $start = [Math]::Max(0, $agents.Count - $maxAgents)
    for ($i = $agents.Count - 1; $i -ge $start; $i--) {
        $agent = $agents[$i]
        $status = [string](Get-JsonValue $agent "status" "success")
        $sIcon = "✓"
        $color = "green"
        if ($status -eq "running") { $sIcon = "◐"; $color = "yellow" }
        elseif ($status -eq "failure") { $sIcon = "✗"; $color = "red" }

        $typeLabel = [string](Get-JsonValue $agent "subagentType" "agent")
        if ([string]::IsNullOrWhiteSpace($typeLabel)) { $typeLabel = "agent" }
        $desc = [string](Get-JsonValue $agent "description" "")
        $lines.Add("$(Colorize $sIcon $color) $(Colorize "[$($typeLabel.ToLower())]" "cyan") $desc")
    }
}

foreach ($line in $lines) {
    Write-Output "$Reset$line"
}
