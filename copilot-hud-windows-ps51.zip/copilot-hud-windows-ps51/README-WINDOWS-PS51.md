# copilot-hud Windows rewrite: no Node.js, no jq, Windows PowerShell 5.1

This is a native Windows rewrite of the key runtime pieces from `griches/copilot-hud`.

## Why this rewrite exists

The upstream repository is a Node/TypeScript plugin whose package entry point is `dist/index.js`, and its package declares Node.js `>=18.0.0`. The upstream hook layer is Bash-based and uses `jq` to parse JSON. That combination is not suitable for a locked-down Windows machine with no Node.js, no jq, and no PowerShell 7.

This version targets:

- Windows PowerShell 5.1 using `powershell.exe`
- no Node.js
- no jq
- Windows Terminal / modern console ANSI output
- Git for Windows, optional, only for branch/dirty/ahead/behind display

## Files

```text
copilot-hud.ps1                    # native status line renderer
scripts/common.ps1                 # shared hook helpers
scripts/session-start.ps1          # sessionStart hook
scripts/user-prompt.ps1            # userPromptSubmitted hook
scripts/pre-tool-use.ps1           # preToolUse hook
scripts/post-tool-use.ps1          # postToolUse hook
scripts/session-end.ps1            # sessionEnd hook
hooks.windows.json                 # Windows hook config using powershell.exe
install-windows-ps51.ps1           # copies files and updates ~/.copilot/config.json
```

## Install status line

From the extracted folder:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install-windows-ps51.ps1
```

Then start Copilot CLI with experimental mode if your version requires it:

```powershell
copilot --experimental
```

## Manual statusLine config

If you prefer to edit `%USERPROFILE%\.copilot\config.json` manually:

```json
{
  "experimental": true,
  "statusLine": {
    "type": "command",
    "command": "powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"C:\\Users\\YOURID\\.copilot\\copilot-hud.ps1\""
  }
}
```

Use your real Windows profile path.

## Hook support

The upstream `hooks.json` uses Bash entries. This rewrite provides `hooks.windows.json` with `command` entries that call PowerShell.

Use it only if your Copilot CLI/plugin hook runner accepts the `command` hook key. If the hook runner only accepts the upstream `bash` key, the status line will still render model/context/git data, but tool/agent tracking will not update because the hook scripts will not run.

## Test the renderer without Copilot

```powershell
'{"cwd":"C:\\work\\repo","session_id":"abc","model":{"display_name":"claude-sonnet-4.6 (1x) (medium)"},"context_window":{"context_window_size":200000,"remaining_tokens":130000,"used_percentage":35,"total_input_tokens":24100,"total_output_tokens":8420},"cost":{"total_duration_ms":300000,"total_api_duration_ms":45000,"total_premium_requests":3,"total_lines_added":42,"total_lines_removed":5}}' |
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$env:USERPROFILE\.copilot\copilot-hud.ps1"
```

## Optional environment variables

```powershell
$env:COPILOT_HUD_ASCII = "1"       # use # and - instead of Unicode bar chars
$env:COPILOT_HUD_NO_COLOR = "1"    # disable ANSI colors
$env:COPILOT_HUD_PATH_LEVELS = "2" # show last 2 path levels
```

## What works

- context usage loading bar
- premium request count when provided by Copilot session JSON
- model badge
- project path
- Git branch/dirty/ahead/behind when `git.exe` is available
- line add/remove count
- token in/out/cache stats
- tool/agent tracking when the Windows hooks run

## What is intentionally not included

- npm build
- TypeScript
- Node.js runtime
- jq
- PowerShell 7-only syntax
