. "$PSScriptRoot\common.ps1"

$inputObj = Read-InputJson
if ($null -eq $inputObj) { exit 0 }

$toolName = [string](Get-JsonValue $inputObj "toolName" "")
$resultType = [string](Get-JsonValue $inputObj "toolResult.resultType" "success")
$timestamp = Get-JsonValue $inputObj "timestamp" 0

$stateFile = Get-StateFile
if (!(Test-Path $stateFile)) { exit 0 }

switch ($toolName) {
    "report_intent" { exit 0 }
    "task_complete" { exit 0 }
    "thinking" { exit 0 }
    "list_agents" { exit 0 }
    "write_agent" { exit 0 }
}

if ($toolName -eq "task") {
    exit 0
}

$status = "success"
switch ($resultType) {
    "success" { $status = "success" }
    "failure" { $status = "failure" }
    "denied"  { $status = "denied" }
    default   { $status = "success" }
}

Invoke-StateLock $stateFile {
    $state = Read-State $stateFile

    if ($toolName -eq "read_agent") {
        $agents = @($state.agents)
        for ($i = 0; $i -lt $agents.Count; $i++) {
            if ([string](Get-JsonValue $agents[$i] "status" "") -eq "running") {
                Set-JsonProperty $agents[$i] "status" $status
                Set-JsonProperty $agents[$i] "endTime" $timestamp
                break
            }
        }
        Set-JsonProperty $state "agents" $agents
        Write-State $state $stateFile
        exit 0
    }

    $tools = @($state.recentTools)
    $matchIndex = -1

    for ($i = 0; $i -lt $tools.Count; $i++) {
        $n = [string](Get-JsonValue $tools[$i] "name" "")
        $s = [string](Get-JsonValue $tools[$i] "status" "")
        if ($n -eq $toolName -and $s -eq "running") {
            $matchIndex = $i
            break
        }
    }

    if ($matchIndex -ge 0) {
        Set-JsonProperty $tools[$matchIndex] "status" $status
        Set-JsonProperty $tools[$matchIndex] "timestamp" $timestamp
    } else {
        $entry = [pscustomobject]@{
            name = $toolName
            status = $status
            timestamp = $timestamp
        }
        $tools = @($entry) + $tools
        if ($tools.Count -gt 8) {
            $tools = @($tools | Select-Object -First 8)
        }
    }

    Set-JsonProperty $state "recentTools" $tools
    Write-State $state $stateFile
}
