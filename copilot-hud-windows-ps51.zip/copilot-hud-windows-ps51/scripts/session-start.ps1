. "$PSScriptRoot\common.ps1"

$inputObj = Read-InputJson
if ($null -eq $inputObj) { exit 0 }

$cwd = Get-JsonValue $inputObj "cwd" ""
$timestamp = Get-JsonValue $inputObj "timestamp" 0
$sessionId = Get-JsonValue $inputObj "sessionId" (Get-JsonValue $inputObj "session_id" "")

$stateFile = Get-StateFile

Invoke-StateLock $stateFile {
    $prevAgents = @()
    if (Test-Path $stateFile) {
        $prevState = Read-State $stateFile
        $prevSid = Get-JsonValue $prevState "sessionId" ""
        if ($prevSid -eq $sessionId -and ![string]::IsNullOrWhiteSpace($sessionId)) {
            $prevAgents = @($prevState.agents)
        }
    }

    $state = [pscustomobject]@{
        sessionId = $sessionId
        sessionStart = $timestamp
        cwd = $cwd
        lastPrompt = $null
        lastPromptTime = $null
        recentTools = @()
        agents = $prevAgents
        sessionActive = $true
    }

    Write-State $state $stateFile
}
