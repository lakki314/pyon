. "$PSScriptRoot\common.ps1"

$inputObj = Read-InputJson
if ($null -eq $inputObj) { exit 0 }

$toolName = [string](Get-JsonValue $inputObj "toolName" "")
$toolArgsRaw = Get-JsonValue $inputObj "toolArgs" $null
$toolArgs = Convert-ToolArgsToObject $toolArgsRaw
$timestamp = Get-JsonValue $inputObj "timestamp" 0

$stateFile = Get-StateFile
if (!(Test-Path $stateFile)) { exit 0 }

switch ($toolName) {
    "report_intent" { exit 0 }
    "task_complete" { exit 0 }
    "thinking" { exit 0 }
    "read_agent" { exit 0 }
    "list_agents" { exit 0 }
    "write_agent" { exit 0 }
}

Invoke-StateLock $stateFile {
    $state = Read-State $stateFile

    if ($toolName -eq "task") {
        $description = [string](Get-JsonValue $toolArgs "description" "")
        $subagentType = [string](Get-JsonValue $toolArgs "agent_type" "")

        if (![string]::IsNullOrWhiteSpace($description)) {
            $entry = [pscustomobject]@{
                description = $description
                subagentType = $(if ([string]::IsNullOrWhiteSpace($subagentType)) { $null } else { $subagentType })
                status = "running"
                startTime = $timestamp
            }

            $agents = @($state.agents)
            $agents += $entry
            Set-JsonProperty $state "agents" $agents
            Write-State $state $stateFile
        }

        exit 0
    }

    $target = ""

    if ($toolName -eq "edit" -or $toolName -eq "view" -or $toolName -eq "create") {
        $target = [string](Get-JsonValue $toolArgs "path" (Get-JsonValue $toolArgs "file_path" ""))
    } elseif ($toolName -eq "bash" -or $toolName -eq "powershell") {
        $command = [string](Get-JsonValue $toolArgs "command" "")
        $firstLine = ($command -split "`r?`n")[0]
        $firstLine = $firstLine -replace "^cd\s+[^&]+&&\s*", ""
        if ($firstLine.Length -gt 60) {
            $target = $firstLine.Substring(0, 60)
        } else {
            $target = $firstLine
        }
    }

    $entry = [pscustomobject]@{
        name = $toolName
        target = $(if ([string]::IsNullOrWhiteSpace($target)) { $null } else { $target })
        status = "running"
        timestamp = $timestamp
    }

    $tools = @($state.recentTools)
    $tools = @($entry) + $tools
    if ($tools.Count -gt 8) {
        $tools = @($tools | Select-Object -First 8)
    }

    Set-JsonProperty $state "recentTools" $tools
    Write-State $state $stateFile
}
