# Common functions for copilot-hud Windows PowerShell 5.1 hooks.
$ErrorActionPreference = "SilentlyContinue"

function Get-CopilotHome {
    if (![string]::IsNullOrWhiteSpace($env:COPILOT_HOME)) {
        return $env:COPILOT_HOME
    }
    return (Join-Path $HOME ".copilot")
}

function Get-StateFile {
    $homeDir = Get-CopilotHome
    if (!(Test-Path $homeDir)) {
        New-Item -ItemType Directory -Path $homeDir -Force | Out-Null
    }
    return (Join-Path $homeDir "hud-state.json")
}

function Get-JsonValue {
    param(
        [Parameter(Mandatory=$false)] $Obj,
        [Parameter(Mandatory=$true)] [string] $Path,
        [Parameter(Mandatory=$false)] $Default = $null
    )

    $cur = $Obj
    foreach ($part in $Path.Split(".")) {
        if ($null -eq $cur) { return $Default }
        $prop = $cur.PSObject.Properties[$part]
        if ($null -eq $prop) { return $Default }
        $cur = $prop.Value
    }

    if ($null -eq $cur) { return $Default }
    return $cur
}

function Set-JsonProperty {
    param($Obj, [string]$Name, $Value)

    if ($null -eq $Obj.PSObject.Properties[$Name]) {
        Add-Member -InputObject $Obj -NotePropertyName $Name -NotePropertyValue $Value -Force
    } else {
        $Obj.$Name = $Value
    }
}

function Read-InputJson {
    $raw = [Console]::In.ReadToEnd()
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    try {
        return ($raw | ConvertFrom-Json)
    } catch {
        return $null
    }
}

function Read-State {
    param([string]$StateFile)

    if (!(Test-Path $StateFile)) {
        return [pscustomobject]@{
            recentTools = @()
            agents = @()
            sessionActive = $false
        }
    }

    try {
        $raw = Get-Content -LiteralPath $StateFile -Raw -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { throw "empty" }
        $state = $raw | ConvertFrom-Json

        if ($null -eq $state.PSObject.Properties["recentTools"]) {
            Add-Member -InputObject $state -NotePropertyName "recentTools" -NotePropertyValue @() -Force
        }
        if ($null -eq $state.PSObject.Properties["agents"]) {
            Add-Member -InputObject $state -NotePropertyName "agents" -NotePropertyValue @() -Force
        }

        return $state
    } catch {
        return [pscustomobject]@{
            recentTools = @()
            agents = @()
            sessionActive = $false
        }
    }
}

function Write-State {
    param($State, [string]$StateFile)

    $dir = Split-Path -Parent $StateFile
    if (!(Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    $tmp = "$StateFile.tmp"
    ($State | ConvertTo-Json -Depth 20) | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $StateFile -Force
}

function Invoke-StateLock {
    param([string]$StateFile, [scriptblock]$ScriptBlock)

    $lockDir = "$StateFile.lock"
    $acquired = $false

    for ($i = 0; $i -lt 40; $i++) {
        try {
            New-Item -ItemType Directory -Path $lockDir -ErrorAction Stop | Out-Null
            $acquired = $true
            break
        } catch {
            Start-Sleep -Milliseconds 50
        }
    }

    if (!$acquired) {
        Remove-Item -LiteralPath $lockDir -Recurse -Force -ErrorAction SilentlyContinue
        try {
            New-Item -ItemType Directory -Path $lockDir -ErrorAction Stop | Out-Null
            $acquired = $true
        } catch {
            # Continue without a lock rather than breaking Copilot.
        }
    }

    try {
        & $ScriptBlock
    } finally {
        if ($acquired) {
            Remove-Item -LiteralPath $lockDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function Convert-ToolArgsToObject {
    param($ToolArgs)

    if ($null -eq $ToolArgs) { return $null }

    if ($ToolArgs -is [string]) {
        try {
            return ($ToolArgs | ConvertFrom-Json)
        } catch {
            return $null
        }
    }

    return $ToolArgs
}
