. "$PSScriptRoot\common.ps1"

$inputObj = Read-InputJson
if ($null -eq $inputObj) { exit 0 }

$prompt = Get-JsonValue $inputObj "prompt" ""
$timestamp = Get-JsonValue $inputObj "timestamp" 0
$stateFile = Get-StateFile

if (!(Test-Path $stateFile)) { exit 0 }

Invoke-StateLock $stateFile {
    $state = Read-State $stateFile
    Set-JsonProperty $state "lastPrompt" $prompt
    Set-JsonProperty $state "lastPromptTime" $timestamp
    Write-State $state $stateFile
}
