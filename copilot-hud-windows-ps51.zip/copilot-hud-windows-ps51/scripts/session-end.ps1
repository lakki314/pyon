. "$PSScriptRoot\common.ps1"

$stateFile = Get-StateFile
if (!(Test-Path $stateFile)) { exit 0 }

Invoke-StateLock $stateFile {
    $state = Read-State $stateFile
    Set-JsonProperty $state "sessionActive" $false
    Write-State $state $stateFile
}
